﻿namespace UserManagementApi.Services
{
    public interface IEndpoint
    {
        void MapEndpoints(WebApplication app);
    }
}
